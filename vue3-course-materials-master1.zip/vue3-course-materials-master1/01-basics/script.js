import {createApp, defineComponent} from './vendor/vue.esm-browser.js';

// const meetups = [
//   {
//     "id": 2,
//     "title": "Демо-Митап",
//     "description": "Описание демонстрационного митапа\n\nLorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.",
//     "imageId": null,
//     "image": null,
//     "date": 1592486118010,
//     "organizer": "Demo Organizer",
//     "place": "Internet",
//     "organizing": true,
//     "attending": false
//   },
//   {
//     "id": 5,
//     "title": "Vue.js Moscow #3 - Ozon",
//     "description": "Друзья привет! Открываем регистрацию на третью встречу JavaScript/Vue.js разработчиков и всех интересующихся. В этот раз мы побываем в гостях у компании Ozon по адресу – “Москва, Пресненская Набережная, 10 блок С, Башня на Набережной”\nДля тех кто все же не сможет до нас добраться, будет организована трансляция выступлений.\nМероприятие бесплатное, но необходима регистрация, количество мест ограничено.\nДо встречи!\n\nhttps://www.meetup.com/ru-RU/vue-js-moscow/events/263421476/",
//     "imageId": 4,
//     "image": "https://course-vue.javascript.ru/api/images/4",
//     "date": 1589241600000,
//     "organizer": "Eugeny F.",
//     "place": "Москва, Офис компании Mail.Ru Group",
//     "organizing": false,
//     "attending": false
//   },
//   {
//     "id": 6,
//     "title": "VueConf US",
//     "description": "ATX. Code. Vue.\nhttps://vueconf.us/",
//     "imageId": 5,
//     "image": "https://course-vue.javascript.ru/api/images/5",
//     "date": 1589241600000,
//     "organizer": "Evan You",
//     "place": "USA, AUSTIN CONVENTION CENTER",
//     "organizing": false,
//     "attending": false
//   },
//   {
//     "id": 1,
//     "title": "MSK VUE.JS MEETUP #1",
//     "description": "С каждым днем Vue.js становится популярней, все больше разработчиков и компаний делают ставку на данную технологию — 18 июля при поддержке компании Voximplant пройдет митап сообщества MSK VUE.JS, посвященный фреймворку. Спикеры поделятся опытом разработки, участники сообщества обсудят перспективы развития Vue.js.\n\nhttps://voximplant.timepad.ru/event/986750/",
//     "imageId": 1,
//     "image": "https://course-vue.javascript.ru/api/images/1",
//     "date": 1588896000000,
//     "organizer": "Игорь Ш.",
//     "place": "Москва, офис Voximplant (ул. Мытная 66)",
//     "organizing": false,
//     "attending": true
//   },
//   {
//     "id": 4,
//     "title": "Vue.js Moscow Meetup #2 - Mail.ru",
//     "description": "!!! Внимание !!!\nРегистрация строго по ссылке:\nhttps://corp.mail.ru/ru/press/events/481/ (Регистрация закрыта)\nВы не сможете попасть на мероприятия, не пройдя регистрацию по ссылке выше.\n\nДрузья привет! Открываем регистрацию на вторую встречу JavaScript/Vue.js разработчиков и всех интересующихся.\nДля тех кто все же не сможет до нас добраться, будет организована трансляция выступлений.\n\nhttps://www.meetup.com/ru-RU/vue-js-moscow/events/251880636/\nСсылка на онлайн трансляцию: https://www.youtube.com/watch?v=SiPKxngecQ0",
//     "imageId": 3,
//     "image": "https://course-vue.javascript.ru/api/images/3",
//     "date": 1588636800000,
//     "organizer": "Eugeny F.",
//     "place": "Москва, Офис компании Mail.Ru Group",
//     "organizing": false,
//     "attending": false
//   },
//   {
//     "id": 3,
//     "title": "Vue.js Moscow Meetup #1",
//     "description": "Ссылка на трансляцию: https://www.youtube.com/watch?v=h9NQs0SEVoA\n\nДрузья привет! Рады сообщить о первом московском митапе, посвященном исключительно фреймоврку Vue.js.\n\nНаша встреча пройдет 22 марта 2018 под покровительством компании Acronis в технопарке - Физтехпарк (г.Москва, Долгопрудненское шоссе, д.3)\nПриглашаются все заинтересованные разработчики от начинающих до опытных.\nФизтехпарк находится за МКАД, но не беспокойтесь, будет организован трансфер от станции метро Алтуфьево и после мероприятия обратно.\nДля желающим приехать на собственном транспорте, проблем с парковкой не будет. Для тех кто все же не сможет до нас добраться, будет организована трансляция выступлений.\n\nhttps://www.meetup.com/ru-RU/vue-js-moscow/events/248462774/",
//     "imageId": 2,
//     "image": "https://course-vue.javascript.ru/api/images/2",
//     "date": 1587513600000,
//     "organizer": "Eugeny F.",
//     "place": "Москва, Физтехпарк, офис Acronis",
//     "organizing": false,
//     "attending": true
//   }
// ];
const fetchMeetups = () => fetch('./api/meetups.json').then((res) => res.json());
const App = defineComponent({
  name: 'App',
  data() {
    return {
      hello: 'world',
      meetups: null,
      // filteredMeetups: [],
      filter:{
        date:'all',
        participation:'all',
        search:'',
      },
      view: 'list', //calendar
    }; 
  },

  mounted(){
    fetchMeetups().then((meetups) => {
      this.meetups = meetups;
    });
  },

computed:{
  //Вычислим отфильтрованный список
  filteredMeetups(){
   
    const dateFilter = (meetup) =>
    this.filter.date === 'all' ||
    (this.filter.date === 'past' && new Date(meetup.date) <= new Date()) ||
    (this.filter.date === 'future' && new Date(meetup.date) > new Date());
    
    const participationFilter = (meetup) =>
    this.filter.participation === 'all' ||
    (this.filter.participation === 'organizing' && meetup.organizing) ||
    (this.filter.participation === 'attending' && meetup.attending);
    
    const searchFilter = (meetup) =>
    [meetup.title, meetup.description, meetup.place, meetup.organizer]
    .join(' ')
    .toLowerCase()
    .includes(this.filter.search.toLowerCase());
    
    return this.meetups.filter((meetup) => dateFilter(meetup) && participationFilter(meetup) && searchFilter(meetup));
    
  }
},
  // watch:{
  //   filter:{
  //     deep:true,
  //     immediate: true,
  //     handler(newValue,oldValue){
  //       this.filteredMeetups = this.filterMeetups();
  //     },
  //   },

  //   meetups:{
  //     deep:true,
  //     handler(){
  //       this.filteredMeetups = this.filterMeetups();
  //     }
  //   }
  // },

  methods: {
    filterMeetups() {
     },

    formatAsLocalDate(timestamp) {
      return new Date(timestamp).toLocaleString(navigator.language, {
        year: "numeric",
        month: "long",
        day: "numeric",
      });
    },

    formatAsIsoDate(timestamp) {
      return new Date(timestamp).toISOString().split('T')[0];
    },
  },
});

const app = createApp(App);

const vm = app.mount('#app');

window.vm = vm;