<template>
  <div>Task 02-components/01-MeetupDescription</div>
</template>

<script>
// TODO: Task 02-components/01-MeetupDescription

export default {
  name: 'MeetupDescription',
};
</script>

<style scoped>
/* _meetup-description.css */
.meetup-description {
  padding-top: 33px;
  margin-bottom: 24px;
  font-size: 18px;
  line-height: 28px;
  white-space: pre-wrap;
}
</style>
