/** @implements {import('vue-router').NavigationGuard} */
export function authGuard(to) {
  // TODO: Task AuthGuard
  return true;
}
