<template>
  <div>Task 06-wrappers/06-UiInputDate</div>
</template>

<script>
// TODO: Task 06-wrappers/06-UiInputDate

export default {
  name: 'UiInputDate',
};
</script>
