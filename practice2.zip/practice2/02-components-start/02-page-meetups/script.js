import { createApp, defineComponent } from './vendor/vue.esm-browser.js';
import App from './components/App.js'


const app = createApp(App);

const vm = app.mount('#app');
