import { defineComponent } from '../vendor/vue.esm-browser.js';
import PageMeetups from './PageMeetups.js';
const fetchMeetups = () => fetch('./api/meetups.json').then((res) => res.json());


export default defineComponent({
  name: 'App',
  components: {
    PageMeetups,
  },
  
  template: `<page-meetups/>`
  
});